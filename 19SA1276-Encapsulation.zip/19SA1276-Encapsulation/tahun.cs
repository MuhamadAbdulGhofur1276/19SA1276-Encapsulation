﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19SA1276_Encapsulation
{
    class tahun
    {
        public int tahunprod;
    }
}
